//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/csspeech/license for the full license information.
//

#pragma once
#include "speechapi_c_common.h"

SPXAPI hybrid_speech_config_create(SPXSPEECHCONFIGHANDLE* hconfig, SPXSPEECHCONFIGHANDLE hcloudSpeechConfig, SPXSPEECHCONFIGHANDLE hembeddedSpeechConfig);
